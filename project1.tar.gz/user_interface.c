/***********************************************
//
// NAME:             Michael Peterson
//
// HOMEWORK:         3B
//
// CLASS:            ICS 212
//
// INSTRUCTOR:       Ravi Narayan
//
// FILE:             user_interface.c
//
// DESCRIPTION:
//    user_interface.c holds the main, which runs the user_interface,
//    which gives the user access to the 'bank database' using the 
//    various options listed in the menu. Interacts with database.c 
//    using defined functions within database.c
//
***********************************************/

#include <stdio.h>
#include <string.h>
#include "database.h"

/**********************************************
//
// Function name:    main
//
// Description:      Runs the user_interface, and interacts
//                   with the database's defined functions.
//
// Parameters:       argc (int): number of arguments in command line
//                   argv (char* []): the array of arguments
//
// Return Value:     0 : main ran successfully
**********************************************/

void getAccountNum(int*);
void getAddress(char [],int);


int debug = 0;

int main(int argc, char * argv[])
{
    struct record * start = NULL;

    int exit = 0;
    char input[20];
    int accountnum = 0;
    int* accp;
    char name[20];
    char address[50];
    
    /*read file */
    readfile(&start, "savefile.txt");
    

     /*debug mode*/
    if ((argc == 2) && (strcmp(argv[1],"debug") == 0))
    {
        printf("debug mode on\n");
        debug = 1;
    }
    else if (argc == 2)
    {
        printf("Incorrect input, shutting down program\n");
        exit = 1;        
    }
    else
    {
        printf("debug mode off\n");
    }

    printf("Hello, this is a user interface that interacts with the bank's database\n\n");

    while(exit == 0)
    {
        printf("add: add a new record into the database\n");
        printf("printall: print all the records within the database\n");
        printf("find: find records(s) within the bank's database\n");
        printf("delete: delete existing records within the database\n");
        printf("quit: quit the program\n\n");
        printf("Please type what you would like the program to do: ");
       
        fgets(input, 20, stdin); 
        
        if(strncmp(input, "add", strlen(input)-1) == 0)
        {
            printf("add\n");
            
            accp = &accountnum;
            getAccountNum(accp);

            printf("Please enter name: ");
            fgets(name, 20, stdin);

            getAddress(address, 50);
            while(getchar() != '\n');
            if(addRecord(&start, accountnum, name, address))
            {
                printf("Record has been added successfully\n");
            }
            else
            {
                printf("There was a duplicate in the database, record was not added\n");
            }
        }
        else if(strncmp(input, "printall", strlen(input) - 1) == 0)
        {
            printAllRecords(start);
        }
        else if (strncmp(input, "find", strlen(input) - 1) == 0)
        {
           int findnum;
           printf("What record are you looking for: ");
           scanf("%d", &findnum);
           if(findRecord(start, findnum) == -1)
           {
               printf("\nThere is no record in the database with account# %d\n\n", findnum);
           }
           else
           {
               printf("Record has been found\n"); 
           }
           while(getchar() != '\n');
        }
        else if (strncmp(input, "delete", strlen(input) - 1) == 0)
        {
            int deletenum;
            printf("What record would you like to delete: ");
            scanf("%d", &deletenum);
            if(deleteRecord(&start, deletenum) == -1)
            {
                printf("\nThere is no record in the database with that account #\n\n");
            }
            else
            {
                printf("\nRecord #%d has been removed from the database.\n\n", deletenum);
            }
            while(getchar() != '\n');
        }
        else if (strncmp(input, "quit", strlen(input) - 1) == 0)
        {
            printf("quitting\n");
            exit = 1;
        }
        else
        {
            printf("that is not valid input, try again\n\n");
        } 
    }
    if (debug == 1)
    {
        printf("\n\nUSER_INTERFACE.C DEBUG MODE PRINTS **********\n");
        printf("name value: %s\n", name);
        printf("accountnum value: %d\n", accountnum);
    }
    /* write file */
    if(writefile(start, "savefile.txt") == 0)
    {
        printf("Database is empty, file was not saved\n");
    }
    else
    {
        printf("Database has been saved\n");
    }
    cleanup(&start);

    return 0;
}

/***************************************************
//
// Function Name:     getAccountNum
//
// Description:       changes the value of earlier defined variable
//                    'accountnum' in main via pointer variable
//
// Parameters:        accp (int*): address of variable that holds the account number
//
// Return Values:     none (void return)
//
***************************************************/

void getAccountNum(int * accp)
{
    int num = 0;
    int valid = 0;
    printf("\nEnter new account number: ");
    valid = scanf("%d", &num);

    while((valid != 1) || num < 0)
    {
        while(getchar() != '\n');
        printf("\nPlease enter valid input: ");
        valid = scanf("%d", &num);
    }

    *accp = num;
    while(getchar() != '\n'); /*clear buffer*/
}

/***********************************************
//
// Function name:     getAddress
//
// Description:       gets input from user using fgetc(stdin), and prints
//                    it right back to them.
//
// Parameters:        address (char []): copy of array address[]
//                    size    (int):     array size of address[]
//
// Return Values:     none (void return)
//
***********************************************/

void getAddress(char address[], int size)
{
    int c = 0;
    int index = 0;
    int stop = 0;
    printf("Enter address\nPress '$' to finish typing\nAddress: ");
    
    while((index < size - 1)&& stop != 1)
    {
        c = fgetc(stdin);
        if (c == '$')
        {
            stop = 1;   
        }
        else
        {
            address[index] = c;
            index++;
        }
    } 
    
    index = 0;
    printf("Printing Address:\n");
    while(index < size)
    {
        printf("%c", address[index]);
        index++;
    }
    printf("\n\n");
}





#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "database.h"

extern int debug;

/******************************************************
//
// Function name:    addRecord
//
// Description:      (stub function) using debug mode, returns the values that were
//                   sent into the function via parameters
//
// Parameters:       **rec (record) : pointer variable that holds the address
//                                    of the pointer variable rec.
//                   account  (int) : account number, returns the value account
//                   name  (char[]) : holds the characters of name, returns value of 
//                                    name
//                   address(char[]): holds the address, returns value of address
//
// Return Values:    0 : successfully ran
//
******************************************************/

int addRecord(struct record **head, int account, char name[], char address[])
{
    struct record * current = *head;
    struct record * previous = NULL;
    struct record * newrecord = NULL;
    int found = 1;

    newrecord = (struct record *)malloc(sizeof(struct record));
    newrecord->accountno = account;
    strcpy(newrecord->name, name);
    strcpy(newrecord->address, address);
    newrecord->next = NULL;

    while(current != NULL) /*check for dupes before inserting*/
    {
        if(current->accountno == account)
        {
            found = -1;
        }
        current = current->next;
    }
    current = *head;

    if(*head == NULL) /*linked list is empty*/
    {
        *head = newrecord;
        if (debug == 1)
        {
            printf("Record added to head of the list\n\n");
            printf("Accountno: %d\n", (*head)->accountno);
            printf("Name:      %s", (*head)->name);
            printf("Address:   %s\n", (*head)->address);
        }
    }
    else if((*head)->accountno > account) /*inserting at beginning*/
    {
        newrecord->next = *head;
        *head = newrecord;
    }
    else
    {
        while((current != NULL) && (current->accountno < account) && (found == 1)) /*loop until it finds account number greater than current accountno */
        /* also loops until it reaches the end of the linked list*/
        {
            previous = current;
            current = current->next;    
        }
        newrecord->next = current;
        if(previous != NULL)
        {
            previous->next = newrecord;
        }
        
    }
    return found;
}

/******************************************************
//
// Function Name:     printAllRecords
//
// Description:       (stub function) while in debug mode, prints message 
//                    indicating the function was called successfully
//
// Parameters:        rec (record *): pointer variable that holds the address of rec
//
// Return value:      none (void function)
//
******************************************************/

void printAllRecords(struct record *start)
{
    struct record * current = start;

    if(current == NULL)
    {
        printf("Database is empty\n\n");
    }

    while(current != NULL)
    {
        printf("RECORD #%d\n", current->accountno);
        printf("NAME:    %s", current->name);
        printf("ADDRESS: %s\n\n", current->address);
        current = current->next; 
    }
}

/******************************************************
//
// Function name:       findRecord
//
// Description:         (stub function) prints a message indicating successful
//                      call, and returns the values that were sent to it.
//
// Parameters:          rec (record*) : pointer variable that holds the address
//                                      of rec
//                      account (int) : value of account number, which is to be printed
//                                      to indicate successfull call
//
// Return value:        0 : Successful call
//
**********************************/

int findRecord(struct record *head, int account)
{
    int found = -1;
    struct record * temp = head;

    while((found == -1) && (temp != NULL))
    {
        if((temp->accountno) == account)
        {
            found = 1;
            printf("Record with account#: %d\n", temp->accountno);
            printf("Name:                 %s\n", temp->name);
            printf("Address:              %s\n\n", temp->address);
        }
        else
        {
            temp = temp->next;
        }
    }

    return found;
}

/*******************************************************
//
// Function Name:     deleteRecord
//
// Description:       (stub function) prints a message indicating that the function
//                    call was successful in debug mode. returns the values that were
//                    sent into it.
//
// Parameters:        rec (**record) : the pointer variable the holds the address to a pointer
//                                     variable's address
//                    account (int)  : hold the value of the account number, to be printed, and
//                                     returned to the function call.
//
// Return Value:      0 : successful call 
//
*******************************************************/

int deleteRecord(struct record **head, int account)
{
    struct record * temp;
    struct record * previous;
    int found;

    temp = *head;
    previous = *head;
    found = -1;

    while(temp != NULL) /*check if account is in list*/
    {
        if(temp->accountno == account)
        {
            found = 0;
        }
        temp = temp->next;
    }
    temp = *head;
 

    while(found == 0)
    {
        if((*head) == NULL) /*empty list*/
        {
            if(debug == 1)
            {
                printf("EMPTY LIST\n");
            }
            found = -1;
        }
        else if((temp->next == NULL) && (*head == temp)) /*only node list */
        {
            free(*head);
            *head = NULL;
            found = 1;
            if(debug == 1)
            { 
                printf("ONLY NODE HAS BEEN DELETED\n");
            }
        }
        else if(((temp->accountno) == account) && (*head != temp)) /* deleting in the middle */
        {
           previous->next = temp->next;
           free(temp);
           temp = NULL;
           found = 1; 
        }
        else if (((*head) == temp) && (temp->accountno == account)) /*deleting first node */
        {
            (*head) = temp->next;
            free(temp);
            temp = NULL;
            found = 1;  
        }
        else /*increment if otherwise */
        {
            previous = temp;
            temp = temp->next;
        }
    }

    return found;
}

/*******************************************************
//  Function Name:     writefile
//
//  Description:       Function used at the end of the program to write the contents of the database's linked list into
//                     a .txt file
//
//  Parameters:        head (*record) : the struct record pointer that holds the address of head
//                     file[] (char)  : the name of the .txt file that is being written to
//
// 
//  Return Value:      1 : successful call
//                     0 : nonsuccessful call
//
*******************************************************/

int writefile(struct record * head, char file[])
{
    struct record * temp = head;
    FILE *outfile = fopen(file, "w");
    int found = 1;

    if(temp == NULL)
    {
        found = 0;
    }

    while(temp != NULL)
    {
        if(debug == 1)
        {
            printf("Record %d has been saved to file\n", temp->accountno);
        }
        fprintf(outfile, "%d\n", temp->accountno); 
        fprintf(outfile, "%s", temp->name);
        fprintf(outfile, "%s$\n", temp->address);/*add the '$' to let getaddressfromfile stop reading from the file*/
        /*fprintf(outfile, "%p\n", (void*)temp->next);*/
        temp = temp->next;
    }

    fclose(outfile);
    return found;
}

/*******************************************************
// Function Name:      readfile
//
//  Description:       Function that is used at the beginning of the program and writes the contents from the .txt file
//                     to the database's linked list
//
//  Parameters:        head (**record) : the pointer pointer variable that holds the address of the head pointe variable
//                     file [] (char)  : the name of the .txt file that is being read from
//
//  Return Value:      1 : successful call
//                     0 : nonsuccessful call
//
*******************************************************/

int readfile(struct record ** head, char file[])
{
    FILE *infile = fopen(file, "r");
    int acc;
    char nam[25];
    char add[45];

    while(fscanf(infile, "%d", &acc) == 1)
    {
        fgetc(infile); /*thanks for answering question on clearing buffer */
        fgets(nam, 25, infile); 
        getaddressfromfile(add, 45, infile); /*optional function to get address from file*/
        /*fgetc(infile);*/
        addRecord(head,acc,nam,add);
    }
    fclose(infile);
    return 0;
}

/*******************************************************
// Function Name:      cleanup
// 
//  Description:       Function used at the end of the program, frees up all memory that is being
//                     allocated in the heap.
// 
//  Parameters:        rec (**record) : the pointer to the pointer that hold the address of the pointer
//                                      of the head of the linked list
// 
//  Return Value:      none : void function 
// 
// *******************************************************/

void cleanup(struct record **head)
{
    struct record * current = *head;
    struct record * nextRec;

    if((*head == NULL) && (debug == 1))
    {
        printf("Linked list is empty\n");
    }
    else
    {
        while(current != NULL)
        {
            nextRec = current->next;
            free(current);
            current = nextRec;
        }
        if(debug == 1)
        {
            printf("Linked list has been freed\n");
        }
    }
}

/*******************************************************
// Function Name:      getaddressfromfile
//
//  Description:       Function that is used within readfile to read the address and its multiple lines
//                     that are stored within savefile.txt The code has been copied directly from
//                     user_interface.c and just changed the stdin parameter to infile.
//
//  Parameters:        char : address[] where the function is writing to, to be used in readfile
//                     int  : size      the size of address[]
//                     FILE : * infile  the file that is being read from
//
//  Return Value:      none : void function
// *******************************************************/


void getaddressfromfile(char address[], int size, FILE * infile)
{
    int c = 0;
    int index = 0;
    int stop = 0;

    while((index < size - 1)&& stop != 1)
    {
        c = fgetc(infile);
        if (c == '$')
        {
            stop = 1;
        }
        else
        {
            address[index] = c;
            index++;
        }
    }

}

